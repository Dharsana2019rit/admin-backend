﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace YummyNirvana.Aspects
{
    public class ExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            base.OnException(context);
        }
    }
}
