﻿using Microsoft.EntityFrameworkCore;
using YummyNirvana.Configurations;
using YummyNirvana.Models;

namespace YummyNirvana.Data
{
    public class YummyNirvanaContext : DbContext
    {
        public YummyNirvanaContext()
        {
        }

        public YummyNirvanaContext(DbContextOptions<YummyNirvanaContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Order> Orders { get; set; }
        //public DbSet<CartProductMap> CartProductMaps { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.ApplyConfiguration(new CategoriesConfiguration());
            modelBuilder.ApplyConfiguration(new CartsConfiguration());
            modelBuilder.ApplyConfiguration(new ProductsConfiguration());
            modelBuilder.ApplyConfiguration(new CartsConfiguration());
            //modelBuilder.ApplyConfiguration(new CartProductMapConfiguration());
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data source=(localdb)\\MSSQLLocalDB;initial catalog=YummyNirvana;integrated security=True;");
            base.OnConfiguring(optionsBuilder);
        }
    }
}
