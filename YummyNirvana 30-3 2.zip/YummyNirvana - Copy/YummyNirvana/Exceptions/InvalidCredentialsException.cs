﻿namespace YummyNirvana.Exceptions
{
    public class InvalidCredentialsException : ApplicationException
    {
        public InvalidCredentialsException(string msg) : base(msg) { }
        public InvalidCredentialsException()
        {
            
        }

    }
}