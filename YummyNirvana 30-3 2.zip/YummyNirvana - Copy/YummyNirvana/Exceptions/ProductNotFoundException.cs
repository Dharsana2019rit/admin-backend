﻿using Microsoft.AspNetCore.Mvc.Diagnostics;

namespace YummyNirvana.Exceptions
{
    public class ProductNotFoundException : ApplicationException
    {
        public ProductNotFoundException(string msg) : base(msg)
        {
            
        }
        public ProductNotFoundException()
        {
            
        }
    }
}
