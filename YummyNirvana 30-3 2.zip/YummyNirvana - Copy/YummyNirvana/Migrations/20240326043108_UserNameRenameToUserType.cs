﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YummyNirvana.Migrations
{
    /// <inheritdoc />
    public partial class UserNameRenameToUserType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserName",
                table: "Users",
                newName: "UserType");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserType",
                table: "Users",
                newName: "UserName");
        }
    }
}
