﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YummyNirvana.Migrations
{
    /// <inheritdoc />
    public partial class mg2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CartProductMap_Carts_CartId",
                table: "CartProductMap");

            migrationBuilder.DropForeignKey(
                name: "FK_CartProductMap_Products_ProductId",
                table: "CartProductMap");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CartProductMap",
                table: "CartProductMap");

            migrationBuilder.RenameTable(
                name: "CartProductMap",
                newName: "CartProductMaps");

            migrationBuilder.RenameIndex(
                name: "IX_CartProductMap_ProductId",
                table: "CartProductMaps",
                newName: "IX_CartProductMaps_ProductId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CartProductMaps",
                table: "CartProductMaps",
                columns: new[] { "CartId", "ProductId" });

            migrationBuilder.AddForeignKey(
                name: "FK_CartProductMaps_Carts_CartId",
                table: "CartProductMaps",
                column: "CartId",
                principalTable: "Carts",
                principalColumn: "CartId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CartProductMaps_Products_ProductId",
                table: "CartProductMaps",
                column: "ProductId",
                principalTable: "Products",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CartProductMaps_Carts_CartId",
                table: "CartProductMaps");

            migrationBuilder.DropForeignKey(
                name: "FK_CartProductMaps_Products_ProductId",
                table: "CartProductMaps");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CartProductMaps",
                table: "CartProductMaps");

            migrationBuilder.RenameTable(
                name: "CartProductMaps",
                newName: "CartProductMap");

            migrationBuilder.RenameIndex(
                name: "IX_CartProductMaps_ProductId",
                table: "CartProductMap",
                newName: "IX_CartProductMap_ProductId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CartProductMap",
                table: "CartProductMap",
                columns: new[] { "CartId", "ProductId" });

            migrationBuilder.AddForeignKey(
                name: "FK_CartProductMap_Carts_CartId",
                table: "CartProductMap",
                column: "CartId",
                principalTable: "Carts",
                principalColumn: "CartId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CartProductMap_Products_ProductId",
                table: "CartProductMap",
                column: "ProductId",
                principalTable: "Products",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
