﻿using YummyNirvana.Models;

namespace YummyNirvana.Repositories.CategoryRepository
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetCategories();
        Task<Category> GetCategory(int id);
        Task<Category> AddCategory(Category category);
        Task<Category> UpdateCategory(int id,Category category);
        Task<Category> DeleteCategory(int id);
    }
}
