﻿using YummyNirvana.Models;

namespace YummyNirvana.Services.AuthorizationService
{
    public interface IAuthService
    {
        Task<string> Authorize(Login user,string userRole);
    }
}
